package cs210Assignment1;

/*
 * Developer:David Greene
 * Date: 06/02/2023
 * Purpose of application : Output the phrase 'Hello World!'
*/
public class snhuAssigment1 {

	public static void main(String[] args) {
		//output to screen saying Hello World!
		System.out.println("Hello World!");

	}

}
