/* 
* Developer: David Greene
* Date: 07/02/2023
* Purpose: Output text 'Hello World!' to console
to the screen, and it is amazing */

#include <iostream>

using namespace std;

int main() {
	//output String Hello World! to console
	cout << "Hello World!" << endl;
	return 0;
}
